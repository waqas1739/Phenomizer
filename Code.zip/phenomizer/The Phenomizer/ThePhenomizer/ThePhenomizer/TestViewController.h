//
//  TestViewController.h
//  ThePhenomizer
//
//  Created by SE15 UniB on 06/01/16.
//  Copyright © 2016 SE15 UniB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *backButton;

@end
